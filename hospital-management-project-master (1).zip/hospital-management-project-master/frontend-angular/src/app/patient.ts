export class Patient {
    id: number;
    name: string;
    age: number;
    visitedDoctor: string;
    dateOfVisit: Date;
}
