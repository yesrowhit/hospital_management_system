import { Doctor } from './doctor';

describe('Doctor', () => {
  it('should create an instance', () => {
    expect(new Doctor()).toBeTruthy();
  });
});
