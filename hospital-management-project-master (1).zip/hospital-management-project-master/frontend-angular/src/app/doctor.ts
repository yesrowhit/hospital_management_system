export class Doctor {
    id: number;
    name: string;
    specialization: string;
    numberOfPatientAttended: number;
    
}
